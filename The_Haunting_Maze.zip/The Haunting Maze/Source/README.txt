> When creatinvg a new object in Clickteam Fusion 2.5, go to the manager, 
search for an object called "MoveIt" and install it. This is used for the movement of
the player and the enemy.

> The Game is event driven so source is not available and code cant be copied and pasted between applications.

> The source file must be run with ClickTeam Fusion 2.5.
