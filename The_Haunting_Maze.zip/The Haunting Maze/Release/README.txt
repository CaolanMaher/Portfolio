The game runs on MS Windows. 
Just run the .exe file.